# SiYuan Tag Styler 🎨

Transform your plain SiYuan tags into beautiful, high-performance "Pills." This plugin works across the entire application, including the **Protyle Editor**, **Outline Panel**, and the **Global Search Results**.

## ✨ Features

- **Global Defaults**: Set one baseline style for all your tags in seconds.
- **Advanced Search Styling**: The only plugin that styles tags right inside the search results list, even with partial matches!
- **Pill or Rounded**: Choose between ultra-smooth pills or modern rounded corners.
- **Virtual # Toggle**: Decide whether to show the `#` symbol globally or per-tag.
- **Position Control**: Float your tags to the end of a block for a cleaner, "Property-like" look.
- **Stealth Mode**: Advanced DOM protection prevents SiYuan's search highlighter from breaking your custom styles.

## 🚀 Installation

1. Go to **Settings** -> **Bazaar** -> **Plugins**.
2. Search for **Tag Styler**.
3. Click **Install**.

## 🛠 Usage

1. Open the **Plugin Settings** (Gear icon).
2. Use the **Global Defaults** card to set your primary look.
3. Click **Add Tag Customization** to give specific tags (like `#todo` or `#urgent`) their own unique colors.
4. **Float End**: Use this to move tags to the right side of your blocks for a dashboard feel.

---
Made with ❤️ for the SiYuan Community.
